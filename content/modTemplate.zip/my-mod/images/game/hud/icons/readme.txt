Put your custom character icons here!

Icons must be formatted like this:
hud/icons/your-character/icon

The image resolution must have a minimal of 300x150