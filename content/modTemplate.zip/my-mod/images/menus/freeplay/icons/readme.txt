Put your freeplay icons here!

Freeplay icons should be formated like this:
freeplay/icons/icon-name/icon.png (icon-name can be whatever you want as long as it matches the one you put in your week.json file)

Icon size must be 150x150!