Put your custom character icons here!

Icons must be formatted like this:
ui/healthHeads/your-character/icon

The image resolution must have a minimal of 300x150