==  SONGS  ==
Put your songs here, it should look like this:

content/songs/your song name here/audio/
---- ./Inst.ogg
---- ./Voices.ogg

Alternatively, it can also look like this if you have separate voice files:

mods/songs/your song name-here/audio/
---- ./Inst.ogg
---- ./Voices-Opponent.ogg
---- ./Voices-Player.ogg