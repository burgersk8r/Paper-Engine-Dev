== DIALOGUES ==
Put your json or txt scripts here, it should look something like this:

content/data/levels/dialogues/
---- songNameDialogue.json (or it can be whatever name you choose)
---- songName.txt