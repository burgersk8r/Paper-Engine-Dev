== SONG SPECIFIC SCRIPTS ==
Put your lua or hx scripts here, it should look something like this:

content/data/levels/scripts/your song name/
---- your script here.lua
---- YourScriptHere.hx